<?php exit;?>{
    "public_html": {
        "name": "public_html",
        "path": "\/home\/u519137383\/domains\/stmik-dci.ac.id\/public_html\/",
        "ext": null,
        "type": "folder"
    }
}