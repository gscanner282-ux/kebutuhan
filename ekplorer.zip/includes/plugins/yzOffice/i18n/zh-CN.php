<?php
return array(
	"yzOffice.meta.name"				=> "永中office预览",
	"yzOffice.meta.title"				=> "永中office",
	"yzOffice.meta.desc"				=> "office系列文件在线预览",

	'yzOffice.config.cacheFile'			=> "开启缓存",
	'yzOffice.config.cacheFileDesc'		=> "开启后,office解析生成的图片等文件存储于本服务器;",
	'yzOffice.config.preview'			=> "预览模式",
	'yzOffice.config.previewDesc'		=> "普通模式,复杂排版的内容会转为图片;",
	'yzOffice.config.previewNormal'		=> "普通模式",
	'yzOffice.config.previewHight'		=> "高清模式",


	'yzOffice.Main.transfer' 			=> "1.数据传输中,请稍后...",
	'yzOffice.Main.converting'			=> '2.文件转换中,请稍后...',
	'yzOffice.Main.uploadError' 		=> "上传失败,请检查php执行超时时间!",
	'yzOffice.Main.convert' 			=> "正在转换,请稍后...",
	'yzOffice.Main.transferAgain'		=> "重新转换"
);